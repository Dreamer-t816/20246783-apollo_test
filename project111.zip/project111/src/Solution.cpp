#include"Solution.h"

void Solution::solve(std::vector<std::vector<char>>& board) {
    int m = board.size();
    int n = board[0].size();

    for (int i = 0; i < m; ++i) {
        if (board[i][0] == 'O') dfs(board, i, 0);
        if (board[i][n - 1] == 'O') dfs(board, i, n - 1);
    }
    for (int j = 0; j < n; ++j) {
        if (board[0][j] == 'O') dfs(board, 0, j);
        if (board[m - 1][j] == 'O') dfs(board, m - 1, j);
    }

    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            if (board[i][j] == 'O') {
                board[i][j] = 'X';
            } else if (board[i][j] == '*') {
                board[i][j] = 'O';
            }
        }
    }
}

// 实现Solution类中的dfs函数
void Solution::dfs(std::vector<std::vector<char>>& board, int x, int y) {
    int m = board.size();
    int n = board[0].size();

    board[x][y] = '*';

    for (const auto& dir : directions) {
        int nextX = x + dir[0];
        int nextY = y + dir[1];
        if (nextX >= 0 && nextX < m && nextY >= 0 && nextY < n && board[nextX][nextY] == 'O') {
            dfs(board, nextX, nextY);
        }
    }
}