#include <iostream>
#include <vector>
#include "Solution.h"

using namespace std;

// 实现Solution类中的solve函数


int main() {
    std::vector<std::vector<char>> board = {
        {'X', 'X', 'X', 'X'},
        {'X', 'O', 'O', 'X'},
        {'X', 'X', 'O', 'X'},
        {'X', 'O', 'X', 'X'}
    };

    Solution solution;
    solution.solve(board);

    std::cout << "处理后的矩阵如下：" << std::endl;
    for (const auto& row : board) {
        for (char cell : row) {
            std::cout << cell << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}