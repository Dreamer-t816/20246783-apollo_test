
#define SOLUTION_H
#include <vector>
#include<bits/stdc++.h>
class Solution {
public:
    std::vector<std::vector<int>> directions = { {1, 0}, {-1, 0}, {0, 1}, {0, -1} };

    void solve(std::vector<std::vector<char>>& board);

private:
    void dfs(std::vector<std::vector<char>>& board, int x, int y);
};